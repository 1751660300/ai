# -*- coding:utf-8 -*-
from distutils.core import setup

setup(name='StrUtils',
      version='1.0',
      author='Qiune',
      description='my string utils',
      author_email="email@someplace.com",
      url="whatever"
)
